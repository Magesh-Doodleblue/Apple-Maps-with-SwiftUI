//
//  mapApp.swift
//  map
//
//  Created by DB-MM-011 on 13/06/23.
//

import SwiftUI

@main
struct mapApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
